// Brand.jsx — single source of truth for the Fancy Floors identity.
// The parent PNG is NEVER modified, recolored, or inverted. To guarantee
// legibility over imagery, the lockup sits on a paper-50 plate. The plate
// is invisible when nested inside the scrolled nav (same color) and
// reads as a deliberate brass-plaque-like brand anchor when over the hero.
//
// Variants:
//   "lockup" — used in top nav. Plate + parent logo + hairline + division label.
//   "footer" — vertical stack used in the footer brand block.
//   "mark"   — bare PNG used in the curtain and very small contexts.
const Brand = ({ variant = 'lockup', label = 'Millwork', size = 44, plated = true }) => {
  if (variant === 'mark') {
    return (
      <span className="fm-brand fm-brand--mark">
        <img src="../../assets/fancyfloors-logo-v2.png" alt="Fancy Floors" style={{ height: size, width: 'auto' }} />
      </span>
    );
  }

  if (variant === 'footer') {
    return (
      <div className="fm-brand fm-brand--footer">
        <img src="../../assets/fancyfloors-logo-v2.png" alt="Fancy Floors Incorporated" style={{ height: 72 }} />
        <div className="fm-brand__division">
          <span className="fm-mono fm-mono--xs">Architectural Millwork Division</span>
        </div>
      </div>
    );
  }

  return (
    <span className={`fm-brand fm-brand--lockup ${plated ? 'is-plated' : ''}`}>
      <span className="fm-brand__plate">
        <img className="fm-brand__mark"
             src="../../assets/fancyfloors-logo-v2.png"
             alt="Fancy Floors"
             style={{ height: size }} />
        <span className="fm-brand__rule"></span>
        <span className="fm-brand__division-label">{label}</span>
      </span>
    </span>
  );
};
window.Brand = Brand;
