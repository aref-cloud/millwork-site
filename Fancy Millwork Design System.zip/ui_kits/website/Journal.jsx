// Journal.jsx — un-indexed editorial coda. Three cards.
const Journal = () => {
  const items = [
    { tag: 'STUDIO NOTE',  date: 'May 2025', title: 'On rift-sawn white oak, and why the cut matters', img: '../../assets/img-kitchen-detail.jpeg' },
    { tag: 'IN PRESS',     date: 'Apr 2025', title: 'Lake House Clubroom featured in Architectural Record',  img: '../../assets/img-lounge-bar-alt.jpeg' },
    { tag: 'STUDIO NOTE',  date: 'Mar 2025', title: 'Specifying hardware for a thirty-year kitchen',       img: '../../assets/img-kitchen-window-sink.jpeg' },
  ];
  return (
    <section id="journal" className="fm-section fm-section--journal">
      <SectionHeader
        eyebrow="Journal"
        headline={<>Notes from the shop.</>}
        lede="Occasional writing on materials, drawings, and the small decisions that hold a project together."
      />
      <div className="fm-journal__grid">
        {items.map((it, i) => (
          <JournalCard key={i} item={it} delay={i * 70} />
        ))}
      </div>
    </section>
  );
};
window.Journal = Journal;

const JournalCard = ({ item, delay }) => {
  const ref = useReveal();
  return (
    <a ref={ref} className="fm-journal__card fm-reveal" href="#" onClick={(e) => e.preventDefault()} style={{ '--d': `${delay}ms` }}>
      <div className="fm-journal__img" style={{ backgroundImage: `url('${item.img}')` }}></div>
      <div className="fm-journal__meta">
        <span className="fm-mono fm-mono--xs">{item.tag} · {item.date}</span>
        <h3 className="fm-journal__title">{item.title}</h3>
        <span className="fm-journal__link">Read note <span className="fm-arrow">→</span></span>
      </div>
    </a>
  );
};
