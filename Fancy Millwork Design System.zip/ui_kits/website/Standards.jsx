// Standards.jsx — chapter 03. Construction & material standards.
// Editorial spec sheet: monochrome, dense, lots of fine rules. The numbers do the work.
const Standards = () => {
  const items = [
    { k: 'Compliance',  v: 'North American Architectural Woodwork Standards — AWI Premium grade or higher.' },
    { k: 'Carcasses',   v: 'High-grade plywood, edge-banded. Engineered for stability across humidity cycles.' },
    { k: 'Doors & drawers', v: 'Solid wood components throughout. Dovetailed drawer boxes; mortise-and-tenon door frames.' },
    { k: 'Hardware',    v: 'Premium soft-close systems. Specified by use, not by line item.' },
    { k: 'Joinery',     v: 'Precise alignment, tight reveals. Tolerances measured in fractions of a millimetre.' },
    { k: 'Finish',      v: 'Multi-stage coating systems designed for life-of-home durability. Hand-rubbed or sprayed.' },
  ];

  return (
    <section id="standards" className="fm-section fm-section--standards">
      <SectionHeader
        eyebrow="Standards" index={3} total={5}
        headline={<>Built to a published<br/>standard, then beyond.</>}
        lede="The AWI Premium grade is a floor, not a ceiling. The materials, the joinery, and the hardware are specified to outlive the homes they live in."
      />

      <div className="fm-standards">
        <ImageBlock />
        <dl className="fm-standards__list">
          {items.map((it, i) => (
            <StandardRow key={i} k={it.k} v={it.v} n={String(i + 1).padStart(2, '0')} delay={i * 60} />
          ))}
        </dl>
      </div>
    </section>
  );
};
window.Standards = Standards;

const StandardRow = ({ k, v, n, delay }) => {
  const ref = useReveal();
  return (
    <div ref={ref} className="fm-standards__row fm-reveal" style={{ '--d': `${delay}ms` }}>
      <span className="fm-mono fm-mono--xs fm-standards__n">{n}</span>
      <dt className="fm-standards__k">{k}</dt>
      <dd className="fm-standards__v">{v}</dd>
    </div>
  );
};

const ImageBlock = () => {
  const ref = useReveal();
  return (
    <figure ref={ref} className="fm-standards__media fm-reveal">
      <TiltFrame img="../../assets/img-kitchen-detail.jpeg" ratio="4/5" />
      <figcaption className="fm-mono fm-mono--xs">DETAIL · DOVETAIL DRAWER BOX · 2024</figcaption>
    </figure>
  );
};
