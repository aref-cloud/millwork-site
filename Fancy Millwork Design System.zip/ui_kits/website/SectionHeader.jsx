// SectionHeader.jsx — the eyebrow + display headline + body pattern used between sections.
// The whole header reveals as a unit when it scrolls into view.
const SectionHeader = ({ eyebrow, index, total, headline, lede, children, align = 'left' }) => {
  const ref = useReveal();
  return (
    <header ref={ref} className={`fm-sec-head fm-sec-head--${align} fm-reveal`}>
      <div className="fm-eyebrow-line">
        <span className="fm-rule"></span>
        <span className="fm-eyebrow">{eyebrow}</span>
        {index && <span className="fm-eyebrow-num">{String(index).padStart(2, '0')} / {String(total).padStart(2, '0')}</span>}
      </div>
      <h2 className="fm-h1 fm-sec-head__title">{headline}</h2>
      {lede && <p className="fm-lede fm-sec-head__lede">{lede}</p>}
      {children}
    </header>
  );
};
window.SectionHeader = SectionHeader;
