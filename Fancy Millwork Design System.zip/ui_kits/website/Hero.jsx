// Hero.jsx — full-bleed image with parallax depth + cinematic staged entrance.
// Quiet by default; the photograph carries the work. JS-driven parallax is gentle.
const Hero = ({ onJump }) => {
  const imgRef = React.useRef(null);
  const reduced = useReducedMotion();

  // Parallax: bg translates at 0.22× scroll speed. No scale shift — just drift.
  React.useEffect(() => {
    if (reduced) return;
    let raf = 0;
    const tick = () => {
      if (!imgRef.current) return;
      const y = window.scrollY;
      if (y > window.innerHeight + 80) { raf = 0; return; }
      imgRef.current.style.transform = `translate3d(0, ${y * 0.22}px, 0) scale(1.04)`;
      raf = 0;
    };
    const onScroll = () => { if (!raf) raf = requestAnimationFrame(tick); };
    window.addEventListener('scroll', onScroll, { passive: true });
    tick();
    return () => { window.removeEventListener('scroll', onScroll); cancelAnimationFrame(raf); };
  }, [reduced]);

  return (
    <section id="top" className="fm-hero">
      <div ref={imgRef} className="fm-hero__img" style={{ backgroundImage: "url('../../assets/img-lounge-coffered.jpeg')" }}></div>
      <div className="fm-hero__scrim"></div>
      <div className="fm-hero__grain" aria-hidden="true"></div>

      {/* Left vertical archive rail — like the spine label of a portfolio book */}
      <div className="fm-hero__rail" aria-hidden="true">
        <span className="fm-mono fm-mono--xs">FM · ARCHIVE</span>
        <span className="fm-hero__rail-rule"></span>
        <span className="fm-mono fm-mono--xs">2008 — 2025</span>
      </div>

      <div className="fm-hero__content">
        <div className="fm-eyebrow fm-eyebrow--light fm-hero__stage" style={{ '--d': '0ms' }}>
          <span className="fm-rule fm-rule--light"></span>
          Fancy Millwork
        </div>
        <h1 className="fm-hero__head fm-hero__stage" style={{ '--d': '220ms' }}>
          <span className="fm-hero__line">Architectural millwork</span>
          <span className="fm-hero__line"><em className="fm-italic">for residences that hold up to a closer look.</em></span>
        </h1>
        <div className="fm-hero__meta fm-hero__stage" style={{ '--d': '560ms' }}>
          <div className="fm-hero__caption">
            <span className="fm-mono fm-mono--xs">Featured · 014</span>
            <span className="fm-caption-light">Lake House Clubroom · Greenwich, Connecticut · 2024</span>
          </div>
          <a className="fm-hero__view" href="#work" onClick={(e) => { e.preventDefault(); onJump('work'); }}>
            <span className="fm-hero__view-txt">View work</span>
            <span className="fm-hero__view-rule"></span>
          </a>
        </div>
      </div>
    </section>
  );
};
window.Hero = Hero;
