// TopNav.jsx — sticky top navigation with the plated brand lockup at left.
// The plate's paper-50 fill gives the parent logo contrast against the hero
// image; when scrolled, the plate dissolves into the warm nav background.
const TopNav = ({ activeSection, onJump }) => {
  const [scrolled, setScrolled] = React.useState(false);
  const [open, setOpen] = React.useState(false);

  React.useEffect(() => {
    const on = () => setScrolled(window.scrollY > 80);
    window.addEventListener('scroll', on, { passive: true });
    on();
    return () => window.removeEventListener('scroll', on);
  }, []);

  React.useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [open]);

  const items = [
    { id: 'work',      label: 'Work',      n: '01' },
    { id: 'practice',  label: 'Practice',  n: '02' },
    { id: 'standards', label: 'Standards', n: '03' },
    { id: 'studio',    label: 'Studio',    n: '04' },
    { id: 'process',   label: 'Process',   n: '05' },
    { id: 'journal',   label: 'Journal',   n: '' },
  ];

  const go = (id) => { setOpen(false); onJump(id); };

  return (
    <React.Fragment>
      <header className={`fm-nav ${scrolled || open ? 'is-scrolled' : ''}`}>
        <a href="#top" className="fm-nav__brand" onClick={(e) => { e.preventDefault(); go('top'); }}>
          <Brand variant="lockup" label="Millwork" size={44} />
        </a>
        <nav className="fm-nav__links">
          {items.map(({ id, label }) => (
            <a key={id} href={`#${id}`} onClick={(e) => { e.preventDefault(); go(id); }}
               className={activeSection === id ? 'is-active' : ''}>
              {label}
            </a>
          ))}
        </nav>
        <button className="fm-btn fm-btn--secondary fm-btn--sm fm-nav__cta" onClick={() => go('contact')}>
          Begin a project
        </button>
        <button
          className={`fm-mobile-toggle ${open ? 'is-open' : ''} ${scrolled || open ? 'is-scrolled' : ''}`}
          onClick={() => setOpen((o) => !o)}
          aria-label={open ? 'Close menu' : 'Open menu'}>
          <span className="fm-mobile-toggle__bar"></span>
          <span className="fm-mobile-toggle__bar"></span>
        </button>
      </header>

      <div className={`fm-mobile-drawer ${open ? 'is-open' : ''}`} aria-hidden={!open}>
        <nav className="fm-mobile-drawer__nav">
          {items.map(({ id, label, n }, i) => (
            <a key={id} href={`#${id}`} onClick={(e) => { e.preventDefault(); go(id); }}
               className={activeSection === id ? 'is-active' : ''}
               style={{ '--mi': i }}>
              <span className="fm-mono fm-mono--xs fm-mobile-drawer__n">{n || '—'}</span>
              <span className="fm-mobile-drawer__label">{label}</span>
            </a>
          ))}
        </nav>
        <div className="fm-mobile-drawer__foot">
          <button className="fm-btn fm-btn--primary" onClick={() => go('contact')}>Begin a project →</button>
          <div className="fm-mobile-drawer__addr">
            <span className="fm-mono fm-mono--xs">studio@fancymillwork.com</span>
            <span className="fm-mono fm-mono--xs">New York · By appointment</span>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
};
window.TopNav = TopNav;
