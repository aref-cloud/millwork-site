# Fancy Millwork — Website UI kit

The marketing site for the Fancy Millwork studio. A single editorial page with sticky top navigation, full-bleed hero, work grid, capabilities, studio, process timeline, journal, and contact footer.

## Files

| File | Purpose |
|---|---|
| `index.html` | App entry — loads React, Babel, all component scripts, and the stylesheets. |
| `site.css` | All component CSS. Imports the design tokens from `../../colors_and_type.css`. |
| `App.jsx` | Top-level composition. Sticky-nav active-section tracking via IntersectionObserver. |
| `TopNav.jsx` | Sticky top navigation. Transparent over the hero, hairline-bordered after scroll. |
| `Hero.jsx` | Full-bleed image hero with editorial headline anchored bottom-left. |
| `SectionHeader.jsx` | Shared eyebrow + index + headline + lede pattern. Used by every major section. |
| `ProjectTile.jsx` | Single project card — image with caption and title beneath. |
| `Work.jsx` | The work grid (alternating 7/5 column tiles). |
| `Capabilities.jsx` | Three-column capabilities listing with dashed bullets. |
| `Studio.jsx` | Two-column studio / about section with photo, body, stats. |
| `Process.jsx` | Dark five-stage process timeline. |
| `Journal.jsx` | Three-up editorial cards linking to studio notes. |
| `Footer.jsx` | "Begin a project" CTA, contact form, address block, legal. |

## Notes for the next designer

- **All design tokens come from `../../colors_and_type.css`.** Don't hand-write hex values in components.
- **Photography is the visual.** Don't add decoration — no badges, no glowing borders, no big rounded radii. The image is the design.
- **Editorial rhythm.** Use the `SectionHeader` for every section opener. The eyebrow + rule + index pattern is the brand signature.
- **No icons unless necessary.** A unicode `→` arrow on a CTA is enough. If a real icon is needed, use Lucide via CDN (see README iconography).
- **Tested down to ~1100px.** Below that it cascades to a 1-column reading layout. A true mobile pass is still TODO.
