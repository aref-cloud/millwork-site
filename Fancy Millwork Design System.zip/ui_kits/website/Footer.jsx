// Footer.jsx — closing brand block. Quiet, address-card style. No social bravado.
const Footer = () => (
  <footer id="contact" className="fm-footer">
    <div className="fm-footer__grid">
      <div className="fm-footer__lead">
        <span className="fm-eyebrow">Begin a project</span>
        <h2 className="fm-display-2 fm-footer__head">
          Currently accepting<br/>2026 commissions.
        </h2>
        <p className="fm-lede fm-footer__lede">Send a brief — a project description, drawings if available, anticipated timeline. We reply within five business days.</p>
      </div>
      <form className="fm-footer__form" onSubmit={(e) => e.preventDefault()}>
        <div className="fm-field">
          <label className="fm-eyebrow">Your name</label>
          <input type="text" defaultValue="" placeholder="Full name" />
        </div>
        <div className="fm-field">
          <label className="fm-eyebrow">Practice or firm</label>
          <input type="text" defaultValue="" placeholder="Architect, designer, or owner" />
        </div>
        <div className="fm-field">
          <label className="fm-eyebrow">Project location</label>
          <input type="text" defaultValue="" placeholder="City, state" />
        </div>
        <div className="fm-field">
          <label className="fm-eyebrow">Brief</label>
          <textarea rows="3" placeholder="A sentence or two about the work."></textarea>
        </div>
        <button className="fm-btn fm-btn--primary" type="submit">Send brief →</button>
      </form>
    </div>

    <div className="fm-footer__base">
      <div className="fm-footer__col fm-footer__col--brand">
        <Brand variant="footer" />
      </div>
      <div className="fm-footer__col">
        <span className="fm-eyebrow">Studio</span>
        <p className="fm-footer__addr">New York, NY<br/>By appointment</p>
      </div>
      <div className="fm-footer__col">
        <span className="fm-eyebrow">Inquiries</span>
        <p className="fm-footer__addr">studio@fancymillwork.com</p>
      </div>
      <div className="fm-footer__col">
        <span className="fm-eyebrow">Working in</span>
        <p className="fm-footer__addr">Northeast · Florida · California</p>
      </div>
    </div>

    <div className="fm-footer__legal">
      <span className="fm-mono fm-mono--xs">© Fancy Floors Incorporated · Architectural Millwork Division</span>
      <span className="fm-mono fm-mono--xs">AWI member · Privacy · Terms</span>
    </div>
  </footer>
);
window.Footer = Footer;
