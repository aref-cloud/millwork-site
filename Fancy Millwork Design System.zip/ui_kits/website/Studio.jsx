// Studio.jsx — chapter 04. About + client list. No animated stats; numbers as plaque text.
const Studio = () => {
  const copyRef  = useReveal();
  const mediaRef = useReveal();

  return (
    <section id="studio" className="fm-section fm-section--studio">
      <div className="fm-studio__grid">
        <figure ref={mediaRef} className="fm-studio__media fm-reveal">
          <div className="fm-studio__img" style={{ backgroundImage: "url('../../assets/img-bath-walnut-vanity.jpeg')" }}></div>
          <figcaption className="fm-mono fm-mono--xs">STUDY · WALNUT &amp; ONYX VANITY · 2023</figcaption>
        </figure>
        <div ref={copyRef} className="fm-studio__copy fm-reveal">
          <div className="fm-eyebrow-line">
            <span className="fm-rule"></span>
            <span className="fm-eyebrow">Studio</span>
            <span className="fm-eyebrow-num">04 / 05</span>
          </div>
          <h2 className="fm-h1 fm-studio__head">An architectural<br/>millwork studio.</h2>
          <p className="fm-lede">The architectural millwork division of Fancy Floors. Architect-led residential interiors, selectively undertaken — a single library wall to a complete interior package.</p>
          <p className="fm-body">We document our work like architecture and install it like furniture. Each project moves through the same shop, the same team, and the same drawing standard — from the first measured visit to the last reveal.</p>

          <dl className="fm-studio__stats">
            <div><dt className="fm-mono fm-mono--xs">Projects, 2008–2025</dt><dd>042</dd></div>
            <div><dt className="fm-mono fm-mono--xs">Active team</dt><dd>18</dd></div>
            <div><dt className="fm-mono fm-mono--xs">Shop, sq.ft.</dt><dd>22,000</dd></div>
          </dl>

          <div className="fm-clients">
            <span className="fm-mono fm-mono--xs fm-clients__eyebrow">We work with</span>
            <ul className="fm-clients__list">
              <li>Architects</li>
              <li>Interior designers</li>
              <li>Custom builders</li>
              <li>Discerning private clients</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
};
window.Studio = Studio;
