// Capabilities.jsx — chapter 02, "Practice". Three disciplines, one studio.
// Differentiators sit at the top as the lede; services as three columns.
const Capabilities = () => {
  const groups = [
    {
      eyebrow: 'Custom woodwork',
      headline: 'Residential & commercial.',
      items: [
        'Kitchens and pantries',
        'Walk-in closets and wardrobes',
        'Built-in cabinetry, libraries, paneling',
        'Bathrooms, bars, custom interior features',
        'Full-home millwork packages',
      ],
    },
    {
      eyebrow: 'Coordination',
      headline: 'Design & technical.',
      items: [
        'Architectural shop drawings',
        'Architect and designer collaboration',
        'Material, finish, and specification consulting',
        'Value engineering and scope optimization',
      ],
    },
    {
      eyebrow: 'Fabrication & install',
      headline: 'Built to AWI standards.',
      items: [
        'Furniture-grade craftsmanship',
        'High-end finishing systems',
        'Coordinated production scheduling',
        'Precision, white-glove installation',
        'A single project lead, end to end',
      ],
    },
  ];

  const differentiators = [
    'Architectural-level documentation',
    'Transparent specification',
    'A predictable workflow',
    'Design-driven execution',
  ];

  return (
    <section id="practice" className="fm-section fm-section--capabilities">
      <SectionHeader
        eyebrow="Practice" index={2} total={5}
        headline={<>Three disciplines,<br/>one studio.</>}
        lede="Drawings, fabrication, and installation under a single roof. The same team carries a project from the first measured visit to the last reveal."
      />

      <ul className="fm-diff">
        {differentiators.map((d, i) => (
          <li key={i} className="fm-diff__item">
            <span className="fm-mono fm-mono--xs">0{i + 1}</span>
            <span className="fm-diff__txt">{d}</span>
          </li>
        ))}
      </ul>

      <div className="fm-cap-grid">
        {groups.map((g, gi) => (
          <CapCard key={gi} group={g} ord={gi} delay={gi * 80} />
        ))}
      </div>
    </section>
  );
};
window.Capabilities = Capabilities;

const CapCard = ({ group, ord, delay }) => {
  const ref = useReveal();
  return (
    <article ref={ref} className="fm-cap fm-reveal" style={{ '--d': `${delay}ms` }}>
      <div className="fm-cap__head">
        <span className="fm-mono fm-mono--xs">0{ord + 1}</span>
        <span className="fm-eyebrow">{group.eyebrow}</span>
      </div>
      <h3 className="fm-cap__title">{group.headline}</h3>
      <ul className="fm-cap__list">
        {group.items.map((it, ii) => (
          <li key={ii}><span className="fm-cap__dash">—</span>{it}</li>
        ))}
      </ul>
    </article>
  );
};
