// ProjectTile.jsx — image-led tile with very subtle 3D tilt on hover.
// Inner image translates a few pixels opposite the tilt for true parallax depth.
const ProjectTile = ({ index, total, title, location, year, type, img, size = 'md' }) => {
  const wrapRef = React.useRef(null);
  const imgRef  = React.useRef(null);
  const reduced = useReducedMotion();

  React.useEffect(() => {
    if (reduced) return;
    const wrap = wrapRef.current;
    const innerImg = imgRef.current;
    if (!wrap || !innerImg) return;

    let raf = 0;
    let tx = 0, ty = 0;       // target rotations (deg)
    let cx = 0, cy = 0;       // current rotations
    let active = false;

    const onMove = (e) => {
      const r = wrap.getBoundingClientRect();
      const dx = (e.clientX - r.left) / r.width  - 0.5;
      const dy = (e.clientY - r.top)  / r.height - 0.5;
      // Max 1.2deg — almost imperceptible. The point is presence, not effect.
      tx = -dy * 1.2;
      ty =  dx * 1.2;
      active = true;
      if (!raf) raf = requestAnimationFrame(tick);
    };
    const onLeave = () => {
      tx = 0; ty = 0;
      active = false;
      if (!raf) raf = requestAnimationFrame(tick);
    };
    const tick = () => {
      // Slower lerp — settles like a heavy object.
      cx = fmLerp(cx, tx, 0.06);
      cy = fmLerp(cy, ty, 0.06);
      wrap.style.transform = `perspective(1800px) rotateX(${cx.toFixed(3)}deg) rotateY(${cy.toFixed(3)}deg)`;
      // Inner translates a single pixel or so opposite the tilt. No scale.
      const px = (cy * -0.8).toFixed(2);
      const py = (cx *  0.8).toFixed(2);
      innerImg.style.transform = `translate3d(${px}px, ${py}px, 0)`;

      const settled = Math.abs(cx - tx) < 0.005 && Math.abs(cy - ty) < 0.005;
      if (!settled || active) raf = requestAnimationFrame(tick);
      else raf = 0;
    };

    wrap.addEventListener('mousemove', onMove);
    wrap.addEventListener('mouseleave', onLeave);
    return () => {
      wrap.removeEventListener('mousemove', onMove);
      wrap.removeEventListener('mouseleave', onLeave);
      cancelAnimationFrame(raf);
    };
  }, [reduced]);

  return (
    <a className={`fm-tile fm-tile--${size}`} href="#" onClick={(e) => e.preventDefault()}>
      <div className="fm-tile__frame" ref={wrapRef}>
        <div className="fm-tile__img" ref={imgRef} style={{ backgroundImage: `url('${img}')` }}></div>
        <div className="fm-tile__sheen" aria-hidden="true"></div>
      </div>
      <div className="fm-tile__meta">
        <div className="fm-tile__top">
          <span className="fm-mono fm-mono--xs">{String(index).padStart(3, '0')} / {String(total).padStart(3, '0')}</span>
          <span className="fm-mono fm-mono--xs">{type}</span>
        </div>
        <h3 className="fm-tile__title">{title}</h3>
        <div className="fm-tile__caption">
          <span>{location}</span>
          <span className="fm-tile__year">{year}</span>
        </div>
      </div>
    </a>
  );
};
window.ProjectTile = ProjectTile;
