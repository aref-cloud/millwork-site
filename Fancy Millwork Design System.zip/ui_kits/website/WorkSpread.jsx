// WorkSpread.jsx — four editorial spread compositions used inside the Work stream.
// Each one is a magazine-page layout: irregular columns, captions in margins,
// ghost numerals as anchors, intentional whitespace.
//
// Components exported (via window):
//   <WorkFeatured>  — lead "cover story" project
//   <WorkDuo>       — two projects, asymmetric
//   <WorkPanorama>  — single wide image with bracketing captions

// ----- Featured ------------------------------------------------------------
const WorkFeatured = ({ index, total, title, location, year, type, lede, materials, finish, img }) => {
  const ref = useReveal();
  return (
    <article ref={ref} className="fm-spread fm-spread--featured fm-reveal">
      <span className="fm-spread__ghost" aria-hidden="true">{String(index).padStart(3, '0')}</span>
      <a className="fm-spread__media" href="#" onClick={(e) => e.preventDefault()}>
        <TiltFrame img={img} ratio="5/3.4" />
      </a>
      <aside className="fm-spread__side">
        <div className="fm-eyebrow-line">
          <span className="fm-rule"></span>
          <span className="fm-eyebrow">Featured · {String(index).padStart(3, '0')} / {String(total).padStart(3, '0')}</span>
        </div>
        <h3 className="fm-spread__title">{title}</h3>
        <p className="fm-spread__lede">{lede}</p>
        <dl className="fm-spread__specs">
          <div><dt>Location</dt><dd>{location}</dd></div>
          <div><dt>Type</dt><dd>{type}</dd></div>
          <div><dt>Materials</dt><dd>{materials}</dd></div>
          <div><dt>Finish</dt><dd>{finish}</dd></div>
          <div><dt>Year</dt><dd>{year}</dd></div>
        </dl>
        <a className="fm-ghost-link" href="#" onClick={(e) => e.preventDefault()}>
          <span className="fm-ghost-link__txt">Open project</span>
          <span className="fm-arrow">→</span>
        </a>
      </aside>
    </article>
  );
};
window.WorkFeatured = WorkFeatured;

// ----- Duo -----------------------------------------------------------------
// variant: 'default' (left small / right large offset-down)
//          'offset-right' (left large / right small offset-down)
const WorkDuo = ({ left, right, total, variant = 'default' }) => {
  const ref = useReveal();
  return (
    <article ref={ref} className={`fm-spread fm-spread--duo fm-spread--duo-${variant} fm-reveal`}>
      <DuoCell project={left}  total={total} side="left"  />
      <DuoCell project={right} total={total} side="right" />
    </article>
  );
};
window.WorkDuo = WorkDuo;

const DuoCell = ({ project, total, side }) => (
  <a className={`fm-duo-cell fm-duo-cell--${side}`} href="#" onClick={(e) => e.preventDefault()}>
    <TiltFrame img={project.img} ratio={project.ratio || '4/5'} />
    <div className="fm-duo-cell__meta">
      <span className="fm-mono fm-mono--xs">{String(project.index).padStart(3, '0')} / {String(total).padStart(3, '0')} · {project.type}</span>
      <h3 className="fm-duo-cell__title">{project.title}</h3>
      <span className="fm-mono fm-mono--xs fm-duo-cell__loc">{project.location} · {project.year}</span>
    </div>
  </a>
);

// ----- Panorama ------------------------------------------------------------
const WorkPanorama = ({ index, total, title, location, year, type, note, img }) => {
  const ref = useReveal();
  return (
    <article ref={ref} className="fm-spread fm-spread--panorama fm-reveal">
      <header className="fm-spread__pano-head">
        <div className="fm-eyebrow-line">
          <span className="fm-rule"></span>
          <span className="fm-eyebrow">{type} · {String(index).padStart(3, '0')} / {String(total).padStart(3, '0')}</span>
        </div>
        <h3 className="fm-spread__title">{title}</h3>
      </header>
      <a className="fm-spread__media" href="#" onClick={(e) => e.preventDefault()}>
        <TiltFrame img={img} ratio="16/7" />
      </a>
      <footer className="fm-spread__pano-foot">
        <p className="fm-spread__note">{note}</p>
        <div className="fm-spread__pano-meta">
          <span className="fm-mono fm-mono--xs">{location}</span>
          <span className="fm-mono fm-mono--xs">{year}</span>
        </div>
      </footer>
    </article>
  );
};
window.WorkPanorama = WorkPanorama;

// ----- Shared TiltFrame ----------------------------------------------------
// The same subtle 3D tilt used elsewhere, now reusable.
const TiltFrame = ({ img, ratio = '4/3' }) => {
  const wrapRef = React.useRef(null);
  const imgRef = React.useRef(null);
  const reduced = useReducedMotion();

  React.useEffect(() => {
    if (reduced) return;
    const wrap = wrapRef.current, inner = imgRef.current;
    if (!wrap || !inner) return;
    let raf = 0, tx = 0, ty = 0, cx = 0, cy = 0, active = false;
    const onMove = (e) => {
      const r = wrap.getBoundingClientRect();
      const dx = (e.clientX - r.left) / r.width  - 0.5;
      const dy = (e.clientY - r.top)  / r.height - 0.5;
      tx = -dy * 1.2;
      ty =  dx * 1.2;
      active = true;
      if (!raf) raf = requestAnimationFrame(tick);
    };
    const onLeave = () => { tx = 0; ty = 0; active = false; if (!raf) raf = requestAnimationFrame(tick); };
    const tick = () => {
      cx = fmLerp(cx, tx, 0.06);
      cy = fmLerp(cy, ty, 0.06);
      wrap.style.transform = `perspective(1800px) rotateX(${cx.toFixed(3)}deg) rotateY(${cy.toFixed(3)}deg)`;
      inner.style.transform = `translate3d(${(cy * -0.8).toFixed(2)}px, ${(cx * 0.8).toFixed(2)}px, 0)`;
      const settled = Math.abs(cx - tx) < 0.005 && Math.abs(cy - ty) < 0.005;
      if (!settled || active) raf = requestAnimationFrame(tick); else raf = 0;
    };
    wrap.addEventListener('mousemove', onMove);
    wrap.addEventListener('mouseleave', onLeave);
    return () => {
      wrap.removeEventListener('mousemove', onMove);
      wrap.removeEventListener('mouseleave', onLeave);
      cancelAnimationFrame(raf);
    };
  }, [reduced]);

  return (
    <div className="fm-tiltframe" ref={wrapRef} style={{ aspectRatio: ratio }}>
      <div className="fm-tiltframe__img" ref={imgRef} style={{ backgroundImage: `url('${img}')` }}></div>
    </div>
  );
};
window.TiltFrame = TiltFrame;
