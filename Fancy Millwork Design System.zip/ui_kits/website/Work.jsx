// Work.jsx — Selected Work, presented as four editorial spreads.
//   Spread 01 — Featured (014 Lake House Clubroom)
//   Spread 02 — Duo (013 Hudson Street · 012 Atherton Residence — Primary Bath)
//   Spread 03 — Panorama (011 Hillside Library)
//   Spread 04 — Duo (009 Coastal Wine Room · 010 Westport Kitchen, reversed)
const Work = () => {
  return (
    <section id="work" className="fm-section fm-section--work">
      <SectionHeader
        eyebrow="Selected work" index={1} total={5}
        headline={<>Forty-two projects.<br/>One studio, one standard.</>}
        lede="A small portfolio, chosen carefully. Each project led from drawings to install by the same team."
      />

      <div className="fm-work-stream">
        <WorkFeatured
          index={14} total={42}
          title="Lake House Clubroom"
          location="Greenwich, Connecticut"
          year="2024"
          type="Clubroom & wine room"
          materials="American black walnut · linen · brass"
          finish="Hand-rubbed oil · semi-matte lacquer"
          lede="A library, bar, and screening room within the lower level of a 1923 estate. Coffered ceiling lit indirectly."
          img="../../assets/img-lounge-coffered.jpeg"
        />

        <WorkDuo
          total={42}
          variant="default"
          left={{
            index: 13, title: 'Hudson Street Residence', location: 'New York, NY', year: '2024',
            type: 'Full-home package', ratio: '4/5',
            img: '../../assets/img-kitchen-walnut-floor.jpeg',
          }}
          right={{
            index: 12, title: 'Atherton Residence — Primary Bath', location: 'Atherton, CA', year: '2023',
            type: 'Primary bath', ratio: '4/3',
            img: '../../assets/img-bath-walnut-vanity.jpeg',
          }}
        />

        <WorkPanorama
          index={11} total={42}
          title="Hillside Library"
          location="Los Angeles, California"
          year="2023"
          type="Built-in shelving"
          note="A grid of recessed colour fields within a lacquered cream casework. Integrated cove lighting; reveals held to a one-millimetre tolerance."
          img="../../assets/img-builtin-mondrian-wall.jpeg"
        />

        <WorkDuo
          total={42}
          variant="offset-right"
          left={{
            index: 9, title: 'Coastal Wine Room', location: 'Palm Beach, FL', year: '2023',
            type: 'Wine room', ratio: '4/3',
            img: '../../assets/img-lounge-bar.jpeg',
          }}
          right={{
            index: 10, title: 'Westport Kitchen', location: 'Westport, CT', year: '2023',
            type: 'Kitchen', ratio: '4/5',
            img: '../../assets/img-kitchen-viking-range.jpeg',
          }}
        />
      </div>

      <div className="fm-section__footer">
        <a className="fm-ghost-link" href="#" onClick={(e) => e.preventDefault()}>
          <span className="fm-ghost-link__txt">View the full archive</span>
          <span className="fm-arrow">→</span>
        </a>
        <span className="fm-mono fm-mono--xs">06 selected · 42 total</span>
      </div>
    </section>
  );
};
window.Work = Work;
