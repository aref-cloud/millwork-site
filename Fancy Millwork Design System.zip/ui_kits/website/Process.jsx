// Process.jsx — chapter 05. Five-stage timeline. Dark band; cursor-follow ambient light.
const Process = () => {
  const sectionRef = React.useRef(null);
  const reduced = useReducedMotion();

  React.useEffect(() => {
    if (reduced) return;
    const sec = sectionRef.current;
    if (!sec) return;
    let raf = 0;
    const onMove = (e) => {
      const r = sec.getBoundingClientRect();
      const x = ((e.clientX - r.left) / r.width)  * 100;
      const y = ((e.clientY - r.top)  / r.height) * 100;
      if (raf) return;
      raf = requestAnimationFrame(() => {
        sec.style.setProperty('--fm-light-x', `${x}%`);
        sec.style.setProperty('--fm-light-y', `${y}%`);
        raf = 0;
      });
    };
    sec.addEventListener('mousemove', onMove);
    return () => { sec.removeEventListener('mousemove', onMove); cancelAnimationFrame(raf); };
  }, [reduced]);

  const stages = [
    { n: '01', t: 'Survey & scope',  d: 'A measured visit. The architect\u2019s drawings become a millwork take-off and a transparent scope.' },
    { n: '02', t: 'Documentation',   d: 'Plans, elevations, sections, joinery details. Reviewed and signed by the design team.' },
    { n: '03', t: 'Material & finish', d: 'Species, cut, grain, and finish \u2014 chosen from real boards, never from photographs.' },
    { n: '04', t: 'Fabrication',     d: 'Built in-house to AWI standards. Furniture-grade joinery in a dust-controlled shop.' },
    { n: '05', t: 'Installation',    d: 'Delivered crated. Fitted under our own supervision. Punched to a single list.' },
  ];

  return (
    <section id="process" ref={sectionRef} className="fm-section fm-section--process fm-section--dark">
      <div className="fm-section__light" aria-hidden="true"></div>
      <SectionHeader
        eyebrow="Process" index={5} total={5}
        headline={<>Five stages,<br/>one project lead.</>}
        lede="No phase begins until the previous one is signed off \u2014 by the architect and by us."
      />
      <ol className="fm-process">
        {stages.map((s, i) => (
          <ProcessStep key={s.n} step={s} delay={i * 70} />
        ))}
      </ol>
    </section>
  );
};
window.Process = Process;

const ProcessStep = ({ step, delay }) => {
  const ref = useReveal();
  return (
    <li ref={ref} className="fm-process__step fm-reveal" style={{ '--d': `${delay}ms` }}>
      <div className="fm-process__num">
        <span className="fm-mono fm-mono--num">{step.n}</span>
        <span className="fm-process__dot"></span>
      </div>
      <h3 className="fm-process__title">{step.t}</h3>
      <p className="fm-process__body">{step.d}</p>
    </li>
  );
};
