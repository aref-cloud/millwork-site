// motion.jsx — small, reusable motion utilities. Compositor-only transforms.
//   - useReveal()   : scroll-reveal via IntersectionObserver
//   - useReducedMotion() : honors OS setting
//   - useCountUp()  : numeric easing from 0 to target on reveal
//   - useParallax() : binds [ref] to scroll-linked translateY
//   - clamp/lerp    : tiny math helpers

const useReducedMotion = () => {
  const [reduced, setReduced] = React.useState(false);
  React.useEffect(() => {
    const mql = window.matchMedia('(prefers-reduced-motion: reduce)');
    const set = () => setReduced(mql.matches);
    set();
    mql.addEventListener('change', set);
    return () => mql.removeEventListener('change', set);
  }, []);
  return reduced;
};

// Add `is-in` class when the element scrolls into view.
const useReveal = (options = {}) => {
  const ref = React.useRef(null);
  React.useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      el.classList.add('is-in');
      return;
    }
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) {
          el.classList.add('is-in');
          io.unobserve(el);
        }
      });
    }, { rootMargin: '0px 0px -10% 0px', threshold: 0.1, ...options });
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return ref;
};

// Count from 0 to target with a cinematic ease-out, triggered on reveal.
const useCountUp = (target, { duration = 1400, decimals = 0 } = {}) => {
  const ref = React.useRef(null);
  React.useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const format = (v) => Number(v).toLocaleString('en-US', {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    });
    if (reduced) { el.textContent = format(target); return; }
    el.textContent = format(0);
    let raf;
    const start = (ts) => {
      let t0 = ts;
      const step = (ts2) => {
        const p = Math.min(1, (ts2 - t0) / duration);
        // ease-out cubic
        const eased = 1 - Math.pow(1 - p, 3);
        el.textContent = format(target * eased);
        if (p < 1) raf = requestAnimationFrame(step);
      };
      raf = requestAnimationFrame(step);
    };
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) {
          raf = requestAnimationFrame(start);
          io.unobserve(el);
        }
      });
    }, { threshold: 0.4 });
    io.observe(el);
    return () => { cancelAnimationFrame(raf); io.disconnect(); };
  }, [target, duration, decimals]);
  return ref;
};

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp  = (a, b, t) => a + (b - a) * t;

window.useReducedMotion = useReducedMotion;
window.useReveal = useReveal;
window.useCountUp = useCountUp;
window.fmClamp = clamp;
window.fmLerp = lerp;
