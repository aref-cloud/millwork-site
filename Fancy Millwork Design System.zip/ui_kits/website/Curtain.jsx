// Curtain.jsx — brief brand reveal on first paint. Honors prefers-reduced-motion.
// The curtain renders the parent identity full-screen on a paper-50 field, holds
// briefly, then lifts as the page settles. ~1500ms total. Sets sessionStorage so
// subsequent in-session navigations skip it.
const Curtain = () => {
  const [phase, setPhase] = React.useState(() => {
    if (typeof window === 'undefined') return 'gone';
    if (sessionStorage.getItem('fm-seen')) return 'gone';
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      sessionStorage.setItem('fm-seen', '1');
      return 'gone';
    }
    return 'enter';
  });

  React.useEffect(() => {
    if (phase === 'gone') return;
    const t1 = setTimeout(() => setPhase('hold'), 350);
    const t2 = setTimeout(() => setPhase('lift'), 1300);
    const t3 = setTimeout(() => {
      sessionStorage.setItem('fm-seen', '1');
      setPhase('gone');
    }, 2100);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  }, [phase]);

  if (phase === 'gone') return null;
  return (
    <div className={`fm-curtain fm-curtain--${phase}`} aria-hidden="true">
      <div className="fm-curtain__inner">
        <img src="../../assets/fancyfloors-logo-v2.png" alt="" className="fm-curtain__mark" />
        <span className="fm-mono fm-curtain__division">Architectural Millwork</span>
      </div>
    </div>
  );
};
window.Curtain = Curtain;
