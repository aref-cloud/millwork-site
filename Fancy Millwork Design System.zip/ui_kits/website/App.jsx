// App.jsx — top-level composition for the Fancy Millwork marketing site.
const App = () => {
  const [active, setActive] = React.useState('top');

  React.useEffect(() => {
    const ids = ['top', 'work', 'practice', 'standards', 'studio', 'process', 'journal', 'contact'];
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) setActive(e.target.id);
      });
    }, { rootMargin: '-40% 0px -55% 0px', threshold: 0 });
    ids.forEach((id) => {
      const el = document.getElementById(id);
      if (el) io.observe(el);
    });
    return () => io.disconnect();
  }, []);

  const jump = (id) => {
    const el = document.getElementById(id);
    if (el) {
      const y = el.getBoundingClientRect().top + window.scrollY - 60;
      window.scrollTo({ top: y, behavior: 'smooth' });
    }
  };

  return (
    <React.Fragment>
      <Curtain />
      <TopNav activeSection={active} onJump={jump} />
      <main>
        <Hero onJump={jump} />
        <Work />
        <Capabilities />
        <Standards />
        <Studio />
        <Process />
        <Journal />
      </main>
      <Footer />
    </React.Fragment>
  );
};

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
